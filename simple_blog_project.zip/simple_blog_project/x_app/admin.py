from django.contrib import admin
from .models import Profile,BlogPost,Comment

admin.site.register(Profile)
admin.site.register(BlogPost)
admin.site.register(Comment)